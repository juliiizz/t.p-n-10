import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecetaAppComponent } from './receta-app.component';

describe('RecetaAppComponent', () => {
  let component: RecetaAppComponent;
  let fixture: ComponentFixture<RecetaAppComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RecetaAppComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RecetaAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
