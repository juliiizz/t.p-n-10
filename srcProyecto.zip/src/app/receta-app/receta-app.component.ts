import { Component } from '@angular/core';

@Component({
  selector: 'app-receta-app',
  standalone: true,
  imports: [],
  templateUrl: './receta-app.component.html',
  styleUrl: './receta-app.component.css'
})
export class RecetaAppComponent {

}
