import { Component } from '@angular/core';

@Component({
  selector: 'app-pie-pagina',
  standalone: true,
  imports: [],
  templateUrl: './pie-pagina.component.html',
  styleUrl: './pie-pagina.component.css'
})
export class PiePaginaComponent {

}
