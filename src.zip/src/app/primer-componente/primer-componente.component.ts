import { Component } from '@angular/core';

@Component({
  selector: 'app-primer-componente',
  standalone: true,
  imports: [],
  templateUrl: './primer-componente.component.html',
  styleUrl: './primer-componente.component.css'
})
export class PrimerComponenteComponent {

}
