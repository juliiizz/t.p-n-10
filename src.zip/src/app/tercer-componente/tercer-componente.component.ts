import { Component } from '@angular/core';

@Component({
  selector: 'app-tercer-componente',
  standalone: true,
  imports: [],
  templateUrl: './tercer-componente.component.html',
  styleUrl: './tercer-componente.component.css'
})
export class TercerComponenteComponent {

}
